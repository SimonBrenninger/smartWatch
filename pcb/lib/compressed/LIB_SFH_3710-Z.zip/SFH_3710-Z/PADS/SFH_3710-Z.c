*PADS-LIBRARY-SCH-DECALS-V9*

SFH_3710-Z           32000 32000 100 10 100 10 4 4 0 2 24
TIMESTAMP 2022.04.11.14.44.14
"Default Font"
"Default Font"
450   200   0 8 100 10 "Default Font"
REF-DES
450   100   0 8 100 10 "Default Font"
PART-TYPE
300   -150  0 12 100 10 "Default Font"
*
300   -250  0 12 100 10 "Default Font"
*
COPCLS 4 10 0 -1
200   0    
400   100  
400   -100 
200   0    
OPEN   2 10 0 -1
200   100  
200   -100 
OPEN   2 10 0 -1
100   0    
200   0    
OPEN   2 10 0 -1
400   0    
500   0    
T0     0     0 0 60    10    0 2 140   10    0 16 PINSHORT
P-520  0     0 2 -80   0     0 2 0
T600   0     0 2 60    10    0 2 140   10    0 16 PINSHORT
P-520  0     0 2 -80   0     0 2 0

*END*